#include "signaling_api.h"
#include <chrono>
#include <random>

using namespace lunaricorn::internal;
using namespace std::chrono_literals; 

static constexpr int kHeartbeatIntervalMs = 1000;
static constexpr int kBufReservationB = 1024;

/// Receive buffer size must be large enough to hold the largest expected
/// message from the server (header + JSON payload). 64KB covers typical
/// subscription event batches and query responses without fragmentation.
static constexpr int kRecvBufSize = 65536;
static constexpr auto silence_duration = 5s; 

static uint64_t random_u64()
{
    static std::mt19937_64 engine = [] 
    {
        std::random_device rd;
        auto now = std::chrono::steady_clock::now().time_since_epoch().count();
        uint64_t time_seed = static_cast<uint64_t>(now);
        unsigned int low  = static_cast<unsigned int>(time_seed);
        unsigned int high = static_cast<unsigned int>(time_seed >> 32);
        std::seed_seq seed{rd(), rd(), rd(), low, high};
        return std::mt19937_64{seed};
    }();
    static std::uniform_int_distribution<uint64_t> dist;
    return dist(engine);
}

namespace lunaricorn
{
SignalingConnector::SignalingConnector() :
_hb_timer(kHeartbeatIntervalMs, kHeartbeatIntervalMs),
_raw_port (0)
{
    _proto = std::make_shared<lunaricorn::internal::SignalingProto>();
    _last_send = std::chrono::steady_clock::now();
}
SignalingConnector::~SignalingConnector()
{
    stop();
}
bool SignalingConnector::start(const std::string& host, Poco::UInt16 raw_port)
{
    if (_connected || _runner_thread.has_value()) 
    {
        MLOG_E("SignalingConnector already connected");
        return false;

    }

    if (host.empty() || raw_port == 0)
    {
        MLOG_E("Invalid host or port {}:{}", host, raw_port);
        return false;
    }
    std::lock_guard<std::mutex> lock(_connection_mutex);
    if (_sock)
    {
        // cleanup broken state
        _sock->close();
        _sock.reset();
    }
    _connected = false;
    _host =  host;
    _raw_port = raw_port;
    
    const Poco::Net::SocketAddress addr(_host, _raw_port);
    _sock = std::make_shared<Poco::Net::StreamSocket>(addr);
    _thread_state = std::make_shared<ThreadState>();  // FIX: store state for stop_runner()
    
    // [FIX #2] Set _connected = true BEFORE starting the heartbeat timer.
    // ready() checks _connected && _sock && _sock->impl()->initialized().
    // If _connected is true before the socket is ready for I/O, the heartbeat
    // timer may send messages before runner() starts polling, causing data
    // to remain in the socket buffer unread.
    _connected = true;
    
    _runner_thread = std::jthread([this](std::stop_token st){runner(st, _thread_state);});
    {
        std::lock_guard<std::mutex> lock(_last_send_mutex);
        _last_send = std::chrono::steady_clock::now();
    }
    _hb_timer.start(Poco::TimerCallback<SignalingConnector>(*this, &SignalingConnector::onHBTimer));

    // Reset reconnect strategy on successful manual connect
    _reconnect_strategy.reset();

    return _connected;
}
bool SignalingConnector::stop()
{
    if (_stopping)
    {
        // [BUG] recursive stop
        MBUG("SignalingConnector::stop() called recursively");
        return false;
    }
    _stopping = true;
    _connected = false;
    _auto_reconnect = false; // prevent reconnect loop from starting
    _hb_timer.stop();
    stop_runner();
    std::lock_guard<std::mutex> lock(_connection_mutex);
    if (_sock)
    {
        _sock->close();
        _sock.reset();
    }
    _stopping = false;
    return true;
}

void SignalingConnector::stop_runner()
{
    if (!_runner_thread.has_value())
        return;

    auto& thread = *_runner_thread;
    thread.request_stop();

    if (_thread_state && _thread_state->finished.load(std::memory_order_acquire))
    {
        _runner_thread.reset();
        _thread_state.reset();
        return;
    }

    lunaricorn::internal::OrphanThreadManager::instance().add(
        std::move(thread),
        std::move(_thread_state),
        std::chrono::seconds(10),
        "SignalingConnector::runner"
    );

    _runner_thread.reset();
}

bool SignalingConnector::ready()
{
    return _connected && _sock && _sock->impl()->initialized();
}

seq_t SignalingConnector::make_seq()
{
    seq_t s = _seq;
    ++_seq;
    return s;
}

void SignalingConnector::onHBTimer(Poco::Timer&)
{
    if (!ready()) {return;}

    std::chrono::duration<double> elapsed;
    {
        std::lock_guard<std::mutex> lock(_last_send_mutex);
        elapsed = std::chrono::steady_clock::now() - _last_send;
    }
    if (elapsed >= silence_duration)
    {
        send_client_hb();
    }
}
void SignalingConnector::send_client_hb()
{
    lunaricorn::internal::MessageHeader hb_msg = {
        .magic = lunaricorn::internal::HeaderMagic,
        .version = lunaricorn::internal::PROTOCOL_VERSION,
        .type = lunaricorn::internal::MessageType::MT_HB,
        .data_type = lunaricorn::internal::ContentType::CT_Json,
        .flags = 0,
        .seq = 0, // no responce
        .data_len = 0,
        .crc = 0
    };
    DUMP_HEADER(hb_msg);
    bool sendRc = send_message(hb_msg, boost::json::object());
    if (!sendRc)
    {
        MLOG_E("Failed to send HB message");
    }
}

/// Exponential backoff reconnect loop.
/// Runs in a thread after disconnect. Tries to reconnect with capped exponential
/// backoff + full jitter (1s..60s). On success, restores subscriptions and returns true.
/// Returns false if the connector was stopped (via stop() or destructor).
bool SignalingConnector::reconnect_loop()
{
    MLOG_W("SignalingConnector: starting reconnect loop (auto_reconnect={})", _auto_reconnect);

    while (_auto_reconnect && !_stopping)
    {
        if (!_reconnect_strategy.should_retry())
        {
            MLOG_E("SignalingConnector: max reconnect attempts reached, giving up");
            if (_disconnectCbk)
            {
                try {
                    _disconnectCbk.value()("max reconnect attempts reached", 0);
                } catch (...) {}
            }
            return false;
        }

        auto delay = _reconnect_strategy.next_delay();
        MLOG_W("SignalingConnector: reconnecting in {}ms (attempt #{})",
               delay.count(), _reconnect_strategy.attempt());

        // Sleep with wakeup check for stop
        auto deadline = std::chrono::steady_clock::now() + delay;
        while (std::chrono::steady_clock::now() < deadline)
        {
            if (_stopping || !_auto_reconnect) return false;
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }

        if (_stopping || !_auto_reconnect) return false;

        MLOG_D("SignalingConnector: reconnecting to {}:{}", _host, _raw_port);

        // Attempt to connect
        std::lock_guard<std::mutex> lock(_connection_mutex);
        if (_sock)
        {
            try { _sock->close(); } catch (...) {}
            _sock.reset();
        }

        try
        {
            const Poco::Net::SocketAddress addr(_host, _raw_port);
            _sock = std::make_shared<Poco::Net::StreamSocket>(addr);
            _sock->setBlocking(false);
            _sock->setSendTimeout(Poco::Timespan(1, 0));

            _connected = true;
            _pstate.reset();

            // Restart runner thread
            _thread_state = std::make_shared<ThreadState>();
            _runner_thread = std::jthread([this](std::stop_token st){runner(st, _thread_state);});

            // Restart heartbeat timer
            _hb_timer.restart(kHeartbeatIntervalMs);

            MLOG_W("SignalingConnector: reconnected successfully after {} attempts",
                   _reconnect_strategy.attempt());

            // Restore subscriptions if any were cached
            if (_sub_cache.has_subscription)
            {
                MLOG_D("SignalingConnector: restoring subscription after reconnect");
                // Give the runner thread a moment to start polling
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
                bool sub_ok = subscribe(
                    _sub_cache.types,
                    _sub_cache.sources,
                    _sub_cache.affected,
                    _sub_cache.tags
                );
                if (sub_ok)
                {
                    MLOG_D("SignalingConnector: subscription restored successfully");
                }
                else
                {
                    MLOG_E("SignalingConnector: failed to restore subscription");
                }
            }

            _reconnect_strategy.reset();
            return true;
        }
        catch (const Poco::Exception& e)
        {
            MLOG_W("SignalingConnector: reconnect attempt failed: {}", e.displayText());
            _connected = false;
            if (_sock)
            {
                try { _sock->close(); } catch (...) {}
                _sock.reset();
            }
            continue;
        }
        catch (const std::exception& e)
        {
            MLOG_W("SignalingConnector: reconnect attempt failed: {}", e.what());
            _connected = false;
            if (_sock)
            {
                try { _sock->close(); } catch (...) {}
                _sock.reset();
            }
            continue;
        }
    }

    MLOG_D("SignalingConnector: reconnect loop ended (auto_reconnect={}, stopping={})",
           _auto_reconnect, _stopping.load());
    return false;
}

void SignalingConnector::on_disconnect(const std::string& reason, uint64_t magic)
{
    MLOG_W("SignalingConnector::on_disconnect: reason='{}' magic={}", reason, magic);

    // Notify user callback
    if (_disconnectCbk)
    {
        try
        {
            _disconnectCbk.value()(reason, magic);
        }
        catch (const std::exception& e)
        {
            MLOG_E("on_disconnect callback exception {}", e.what());
        }
    }

    _connected = false;
    _hb_timer.stop();

    // Clean up the runner
    if (_runner_thread.has_value())
    {
        _runner_thread->request_stop();
    }

    // Stop old runner if still running
    stop_runner();

    // Start reconnect loop if auto-reconnect is enabled and we're not stopping
    if (_auto_reconnect && !_stopping)
    {
        MLOG_D("SignalingConnector: triggering reconnect loop");
        reconnect_loop();
    }
}

void SignalingConnector::on_data(std::span<const uint8_t> data)
{
    size_t offset = 0;

    while (offset < data.size())
    {
        if (!_pstate.headerComplete)
        {
            const size_t need = sizeof(lunaricorn::internal::MessageHeader) - _pstate.receivedHeaderBytes;
            const size_t avail = data.size() - offset;
            const size_t take = std::min(need, avail);

            std::memcpy( reinterpret_cast<uint8_t*>(&_pstate.header) + _pstate.receivedHeaderBytes, data.data() + offset, take);
            _pstate.receivedHeaderBytes += take;
            offset += take;

            if (_pstate.receivedHeaderBytes < sizeof(lunaricorn::internal::MessageHeader))
            {
                continue;
            }

            _pstate.headerComplete = true;

            if (_pstate.header.magic != HeaderMagic)
            {
                MLOG_E("invalid header magic: expected=0x{:08X} actual=0x{:08X}", HeaderMagic, _pstate.header.magic);
                _pstate.reset();
                continue; // FIX: continue instead of return — try next bytes
            }

            if (_pstate.header.version != PROTOCOL_VERSION)
            {
                MLOG_E("invalid protocol version: expected={} actual={}", static_cast<uint32_t>(PROTOCOL_VERSION), static_cast<uint32_t>(_pstate.header.version));
                _pstate.reset();
                continue;
            }

            if (_pstate.header.data_len > lunaricorn::internal::MAX_DATA_LEN)
            {
                MLOG_E("payload too large: max={} actual={}",lunaricorn::internal::MAX_DATA_LEN,_pstate.header.data_len);
                _pstate.reset();
                continue; // FIX: continue instead of return — try next bytes
            }

            // Check for size_t overflow: sizeof(MessageHeader) + data_len must not wrap around
            if (sizeof(MessageHeader) + _pstate.header.data_len < sizeof(MessageHeader))
            {
                MLOG_E("data_len overflow detected: data_len={}", _pstate.header.data_len);
                _pstate.reset();
                continue;
            }

            _pstate.buffer.resize(sizeof(MessageHeader) + _pstate.header.data_len);

            std::memcpy(_pstate.buffer.data(), &_pstate.header, sizeof(MessageHeader));
            if (_pstate.header.data_len == 0)
            {
                lunaricorn::internal::IncomingMessage msg;
                if (!_proto->deserializeJson(_pstate.buffer, msg))
                {
                    MLOG_E("deserializeJson failed for empty payload packet: seq={} type={}",_pstate.header.seq,static_cast<uint32_t>(_pstate.header.type));
                    _pstate.reset();
                    continue;
                }

                if (!msg.isValid)
                {
                    MLOG_E("invalid parsed message: seq={} reason={}",_pstate.header.seq,msg.errorReason);
                    _pstate.reset();
                    continue;
                }
                on_message(msg);
                _pstate.reset();
            }
        }

        if (_pstate.headerComplete)
        {
            const size_t need = _pstate.header.data_len - _pstate.receivedPayloadBytes;
            const size_t avail = data.size() - offset;
            const size_t take = std::min(need, avail);
            std::memcpy(_pstate.buffer.data() + sizeof(MessageHeader) + _pstate.receivedPayloadBytes, data.data() + offset, take);
            _pstate.receivedPayloadBytes += take;
            offset += take;

            if (_pstate.receivedPayloadBytes < _pstate.header.data_len)
                continue;

            const size_t expected = sizeof(MessageHeader) + _pstate.header.data_len;

            if (_pstate.buffer.size() != expected)
            {
                MLOG_E("assembled packet size mismatch: expected={} actual={}",expected,_pstate.buffer.size());
                _pstate.reset();
                continue;
            }

            lunaricorn::internal::IncomingMessage msg;

            if (!_proto->deserializeJson(_pstate.buffer, msg))
            {
                MLOG_E("deserializeJson failed: seq={} payload={} bytes",_pstate.header.seq,_pstate.header.data_len);
                _pstate.reset();
                continue;
            }

            if (!msg.isValid)
            {
                MLOG_E("invalid parsed message: seq={} reason={}", _pstate.header.seq, msg.errorReason);
                _pstate.reset();
                continue;
            }
            on_message(msg);
            _pstate.reset();
        }
    } // while
} // SignalingConnector::on_data

void SignalingConnector::on_message(const lunaricorn::internal::IncomingMessage& msg)
{
    const lunaricorn::internal::MessageHeader& header = msg.header;
    DUMP_HEADER(header);
    const auto seq = header.seq;
    if (!msg.isValid)
    {
        MLOG_E("invalid header: seq={} reason={}", header.seq, msg.errorReason);
        return;
    }
    SignalingResponse resp(0);
    {
        std::lock_guard<std::mutex> lock(_pending_responses_mutex);
        auto it = _pending_responses.find(seq);
        if (it == _pending_responses.end())
        {
            on_server_request(msg);
            return;
        }
        resp = it->second;
        _pending_responses.erase(it);
    }
    if (_respCbk)
    {
        resp.ok = msg.isValid;
        resp.data = msg.data;
        resp.error = msg.errorReason;
        try
        {
            _respCbk.value()(resp);
        }
        catch (const std::exception& e)
        {
            MLOG_E("response processing: exception occurred: {}", e.what());
            return;
        }
    }
}

void SignalingConnector::on_server_request(const lunaricorn::internal::IncomingMessage& msg)
{
    const auto type = msg.header.type;
    switch (type)
    {
    case MT_Sub:
    {
        if (!_subCbk) {return;}
        SignalingSubEvent sub(0);
        bool buildRc = sub.build(msg.data);
        if (!buildRc) 
        {
            MLOG_E("cannot build SignalingSubEvent message");
            return;
        }
        try
        {
            _subCbk.value()(sub);
        }
        catch(const std::exception& e)
        {
            MLOG_E("subscribe processing: exception occurred: {}", e.what());
            return;
        }
        break;
    }
    case MT_PubReq:
    {
        if (!_pushCbk) {return;}
        lunaricorn::internal::SignalingEvent event;
        if (msg.data.empty())
        {
            MLOG_E("MT_PubReq with empty data");
            return;
        }
        event.fromDict(msg.data);
        try
        {
            _pushCbk.value()(event);
        }
        catch(const std::exception& e)
        {
            MLOG_E("push processing: exception occurred: {}", e.what());
            return;
        }
        break;
    }
    case MT_HB:
    {
        MLOG_D("on server hb");
        break;
    }
    case MT_Response:
    {
        MLOG_D("on server response (not matched via pending)");
        break;
    }
    default:
    {
        MLOG_E("unknown message type: {}", static_cast<int>(type));
        break;
    }
    }
}

void SignalingConnector::runner(std::stop_token stopToken, std::shared_ptr<lunaricorn::internal::ThreadState> state)
{
    if (!state) {MBUG("no state"); return;}
    struct FinishGuard
    {
        std::shared_ptr<lunaricorn::internal::ThreadState> state;
        ~FinishGuard()
        {
            state->finished.store(true, std::memory_order_release);
        }
    } finishGuard{ state };
    static const Poco::Timespan pollTimeout(100000); // 100ms — Fix #3: reduced from 1s to avoid delayed reads
    std::vector<uint8_t> buffer(kRecvBufSize);
    bool normal_break = true;
    uint64_t magic = 0;
    while (!stopToken.stop_requested())
    {
        normal_break = false;
        magic = random_u64();
        try
        {
            int n = 0;
            {
                std::lock_guard<std::mutex> lock(_connection_mutex);
                if (!_sock)
                {
                    MBUG("no sock object in runner @{}", magic);
                    return;
                }
                if (!_connected)
                {
                    MBUG("not connected @{}", magic);
                    return;
                }
                if (!_sock->poll(pollTimeout, Poco::Net::Socket::SELECT_READ))
                {
                    continue;
                }

                n = _sock->receiveBytes(buffer.data(),static_cast<int>(buffer.size()));
            }
            if (n > 0)
            {
                on_data(std::span<const uint8_t>(buffer.data(), static_cast<size_t>(n)));
                continue;
            } else if (n == 0) {
                on_disconnect("read error _0", magic);
                break;
            }

            MLOG_E("receiveBytes returned invalid size {} @{}", n, magic);
            on_disconnect("read error _1", magic);
            break;
        }
        catch (const Poco::Exception& e)
        {
            MLOG_E("socket exception: {} @{}", e.displayText(), magic);
            on_disconnect("socket exception _2", magic);
            break;
        }
        catch (const std::exception& e)
        {
            MLOG_E("exception: {} @{}", e.what(), magic);
            on_disconnect("socket exception _3", magic);
            break;
        }
        catch (...)
        {
            MLOG_E("unknown exception @{}", magic);
            on_disconnect("unknown exception", magic);
            break;
        }
        normal_break = true;
    }
    if (normal_break)
        MLOG_D("signaling client thread normal exit");
    else
        MLOG_E("thread emergency exit @{}", magic);

}

bool SignalingConnector::send_message(lunaricorn::internal::MessageHeader& msg,const boost::json::object& data)
{
    DUMP_HEADER(msg);
    std::vector<uint8_t> buf;
    if (!data.empty())
    {
        buf.reserve(sizeof(lunaricorn::internal::MessageHeader) + kBufReservationB);
    }
    if (!_proto)
    {
        MBUG(" no proto object!");
        return false;
    }
    size_t sz = _proto->serializeJson(msg, buf, data);
    if(sz == 0){MBUG("Failed to serialize message"); return false;}
    MLOG_D("try to send {}b", sz);
    {
        std::lock_guard<std::mutex> lock(_last_send_mutex);
        _last_send = std::chrono::steady_clock::now();
    }
    std::lock_guard<std::mutex> lock(_connection_mutex);
    return _proto->send_raw(_sock, buf);
}


bool SignalingConnector::push(const SignalingEvent& event)
{
    const seq_t seq = make_seq();
    SignalingPushRequest msg(seq);
    msg.data = event.toDict();
    if (msg.data.empty()) {MBUG("dict is empty"); return false;}
    lunaricorn::internal::MessageHeader header{};
    msg.make_header(header);
    SignalingResponse resp(seq);
    resp.origin.emplace<SignalingPushRequest>(msg);
    DUMP_HEADER(header);
    bool send_rc = send_message(header, msg.data);
    // Fix #4: set _pending_responses AFTER successful send to avoid race condition
    // where response arrives before pending entry is registered
    if (send_rc)
    {
        std::lock_guard<std::mutex> lock(_pending_responses_mutex);
        if (_pending_responses.contains(seq))
        {
            MBUG("seq {} already in pending queue. seq is not unic!", seq);
            return false;
        }
        _pending_responses[seq] = resp;
        MLOG_D("pushed event with seq {}", seq);
    } else {
        MLOG_E("push event failed seq {}", seq);
    }
    return send_rc;
}

bool SignalingConnector::subscribe(const std::vector<std::string>& types,
                                     const std::vector<std::string>& sources,
                                     const std::vector<std::string>& affected,
                                     const std::vector<std::string>& tags)
{
    // Cache subscription parameters for reconnect restore
    {
        _sub_cache.types = types;
        _sub_cache.sources = sources;
        _sub_cache.affected = affected;
        _sub_cache.tags = tags;
        _sub_cache.has_subscription = true;
    }

    if (!ready()) {
        MLOG_E("not connected");
        return false;
    }

    const seq_t seq = make_seq();

    boost::json::object sub_data;
    if (!types.empty()) {
        boost::json::array types_arr;
        for (const auto& t : types) {
            types_arr.push_back(boost::json::value(t));
        }
        sub_data["types"] = std::move(types_arr);
    }
    if (!sources.empty()) {
        boost::json::array src_arr;
        for (const auto& s : sources) {
            src_arr.push_back(boost::json::value(s));
        }
        sub_data["sources"] = std::move(src_arr);
    }
    if (!affected.empty()) {
        boost::json::array aff_arr;
        for (const auto& a : affected) {
            aff_arr.push_back(boost::json::value(a));
        }
        sub_data["affected"] = std::move(aff_arr);
    }
    if (!tags.empty()) {
        boost::json::array tag_arr;
        for (const auto& tg : tags) {
            tag_arr.push_back(boost::json::value(tg));
        }
        sub_data["tags"] = std::move(tag_arr);
    }

    // Create MT_Sub message
    lunaricorn::internal::MessageHeader header{};
    header.magic = lunaricorn::internal::HeaderMagic;
    header.version = lunaricorn::internal::PROTOCOL_VERSION;
    header.type = lunaricorn::internal::MessageType::MT_Sub;
    header.data_type = lunaricorn::internal::ContentType::CT_Json;
    header.flags = 0;
    header.seq = seq;
    header.data_len = static_cast<uint32_t>(boost::json::serialize(sub_data).size());
    header.crc = 0;

    SignalingResponse resp(seq);
    resp.origin.emplace<SignalingPushRequest>(SignalingPushRequest(seq));

    MLOG_D("send subscribe seq={}, types={}", seq, types.size());
    bool send_rc = send_message(header, sub_data);
    // Fix #4: set _pending_responses AFTER successful send to avoid race condition
    // where response arrives before pending entry is registered
    if (send_rc)
    {
        std::lock_guard<std::mutex> lock(_pending_responses_mutex);
        _pending_responses[seq] = resp;
    }
    return send_rc;
}

bool SignalingConnector::query(const boost::json::object& query_params)
{
    if (!ready()) {
        MLOG_E("not connected");
        return false;
    }

    const seq_t seq = make_seq();

    // Create MT_QueryReq message
    lunaricorn::internal::MessageHeader header{};
    header.magic = lunaricorn::internal::HeaderMagic;
    header.version = lunaricorn::internal::PROTOCOL_VERSION;
    header.type = lunaricorn::internal::MessageType::MT_QueryReq;
    header.data_type = lunaricorn::internal::ContentType::CT_Json;
    header.flags = 0;
    header.seq = seq;
    header.data_len = static_cast<uint32_t>(boost::json::serialize(query_params).size());
    header.crc = 0;

    SignalingResponse resp(seq);
    // Use SignalingPushRequest as a placeholder origin (no dedicated QueryRequest class)
    resp.origin.emplace<SignalingPushRequest>(SignalingPushRequest(seq));

    MLOG_D("send query seq={}, params={}", seq, boost::json::serialize(query_params));
    bool send_rc = send_message(header, query_params);
    if (send_rc)
    {
        std::lock_guard<std::mutex> lock(_pending_responses_mutex);
        _pending_responses[seq] = resp;
    }
    return send_rc;
}

bool SignalingConnector::unsubscribe()
{
    if (!ready()) {
        MLOG_E("not connected");
        return false;
    }

    const seq_t seq = make_seq();

    boost::json::object sub_data;
    sub_data["action"] = boost::json::value("unsubscribe");

    lunaricorn::internal::MessageHeader header{};
    header.magic = lunaricorn::internal::HeaderMagic;
    header.version = lunaricorn::internal::PROTOCOL_VERSION;
    header.type = lunaricorn::internal::MessageType::MT_Sub;
    header.data_type = lunaricorn::internal::ContentType::CT_Json;
    header.flags = 0;
    header.seq = seq;
    header.data_len = static_cast<uint32_t>(boost::json::serialize(sub_data).size());
    header.crc = 0;

    MLOG_D("send unsubscribe seq={}", seq);

    // Clear subscription cache on explicit unsubscribe
    _sub_cache.has_subscription = false;
    _sub_cache.types.clear();
    _sub_cache.sources.clear();
    _sub_cache.affected.clear();
    _sub_cache.tags.clear();

    return send_message(header, sub_data);
}

} // namespace lunaricorn
